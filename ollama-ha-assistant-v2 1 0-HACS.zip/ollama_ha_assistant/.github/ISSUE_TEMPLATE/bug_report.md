---
name: Hlášení chyby / Bug Report
about: Ohlásit chybu v integraci
title: "[BUG] "
labels: bug
assignees: ''

---

## Popis problému

Jasně a stručně popi, co se děje špatně.

## Kroky k reprodukci

1. ...
2. ...
3. ...

## Očekávané chování

Co by mělo být místo toho správně?

## Aktuální chování

Co se díeje?

## Informace o prostředí

- **Home Assistant verze:** (např. 2024.6.0)
- **Ollama verze:** (např. 0.1.0)
- **Model:** (např. llama3.1)
- **Adresa Ollama serveru:** (např. http://192.168.1.10:11434)

## Logy z Home Assistant

Prosím přilož relevantní výstup z `config/home-assistant.log`:

```
Vylep si tu obsah logu…
```

## Dodatečný kontext

Cokoli dalšího, co by mohlo pomoci?
