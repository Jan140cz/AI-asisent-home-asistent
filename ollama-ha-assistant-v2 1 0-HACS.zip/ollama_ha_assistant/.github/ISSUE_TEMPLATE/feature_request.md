---
name: Návrh na novou funkci / Feature Request
about: Navrhnout novou funkci nebo zlepšení
title: "[FEATURE] "
labels: enhancement
assignees: ''

---

## Popis návrhu

Jasně popi, co by mělo být přidáno nebo vylepšeno.

## Kde by to bylo užitečné?

Jaký problém by to vyřešilo? Jak by se to používalo?

## Možné řešení

Máš nějakou představu, jak by se to mohlo implementovat?

## Alternativy

Jsou nějaká jiná řešení nebo přístupy?

## Dodatečný kontext

Cokoliv dalšího?
