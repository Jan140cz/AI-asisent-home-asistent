# Pull Request

## Popis

Jasně vysvětli, co dělá tvůj PR a proč.

## Typ změny

- [ ] Bug fix (oprava chyby bez změny chování)
- [ ] Nová funkce (nové chování, bez breaking changes)
- [ ] Breaking change (změna, která mění stávající chování)
- [ ] Dokumentace (aktualizace README, komentářů apod.)

## Jak se to dá testovat?

Popi kroky k ověření tvojí změny.

## Checklist

- [ ] Kód jsem si přečetl a zkontroloval
- [ ] Komentář/dokumentaci jsem aktualizoval
- [ ] Moje změny nevytváří nová varování
- [ ] Přidal jsem testy, pokud je to relevantní
- [ ] Nové a existující unit testy prošly lokálně
- [ ] Testoval jsem změnu v Home Assistant

## Obrázky/Logy

Přilož případné logg nebo screenshoty, které pomáhají pochopit změnu.
