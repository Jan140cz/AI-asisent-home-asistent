# Changelog

Všechny pozoruhodné změny v tomto projektu jsou zdokumentovány v tomto souboru.

Formát vychází z [Keep a Changelog](https://keepachangelog.com/cs/1.0.0/) a
projekt používá [Sémantické verzování](https://semver.org/lang/cs/) (MAJOR.MINOR.PATCH).

## Legenda značek

| Značka | Význam |
|--------|--------|
| 🆕 **NOVÉ** | Nová funkce |
| 🔧 **ZMĚNA** | Změna chování stávající funkce |
| 🐛 **OPRAVA** | Oprava chyby |
| ⚠️ **ROZBÍJEJÍCÍ ZMĚNA** | Vyžaduje zásah uživatele po aktualizaci (viz [UPGRADE_GUIDE.md](UPGRADE_GUIDE.md)) |
| 🗑️ **ZASTARALÉ** | Bude odstraněno v budoucí verzi |
| 🔒 **BEZPEČNOST** | Bezpečnostní oprava |

---

## [2.1.0] - 2026-07-25

### 🆕 NOVÉ

- **🔊 Vlastní hlas asistenta (TTS)** — v Možnostech integrace lze vybrat
  TTS entitu a konkrétní hlas. Nová služba `ollama_assistant.speak` umí
  tímto hlasem přehrát libovolný text na zvoleném přehrávači.
- **📲 Odpovědi na Telegram** — asistent umí každou svou textovou odpověď
  poslat i jako zprávu na Telegram přes existující integraci Telegram bot.
  Postup nastavení: [TELEGRAM_GUIDE.md](TELEGRAM_GUIDE.md).
- **🎨 Vlastní ikona integrace** — přidána `brand/` složka s ikonou a logem,
  takže se integrace v detailu na stránce Nastavení zobrazí s vlastním
  designem místo prázdného čtverce (podrobnosti a současné omezení v HACS
  seznamu viz [ICON_POZNAMKA.md](ICON_POZNAMKA.md)).

### 🔧 ZMĚNY

- Doplněny chybějící popisky (translations) pro volby Face Recognition
  a Lock Control v Možnostech integrace.

**Vyžaduje zásah?** Ne — nové volby mají bezpečné výchozí hodnoty (vypnuto).

---

## [Nevydáno]

### 🆕 NOVÉ
- Připraveno pro budoucí položky

---

## [2.0.0] - 2024-07-25

### ⚠️ ROZBÍJEJÍCÍ ZMĚNY

Tato verze obsahuje **velké změny** v konfiguraci. **Musíš ji ručně aktualizovat:**

- **Nový modul: Face Recognition** — rozpoznávání obličejů z kamer (v přípravě)
- **Nový modul: Lock Control** — automatické odemykání dveří na základě rozpoznaného obličeje

**Postup aktualizace:** Viz [UPGRADE_GUIDE.md#200---2024-07-25](UPGRADE_GUIDE.md)

### 🆕 NOVÉ

- **🎥 Rozpoznávání obličejů (Face Recognition)**
  - Přidán nový modul `face_recognition.py` pro detekci obličejů z kamer
  - Podpora více kamer najednou
  - Nastavitelný práh jistoty (confidence threshold)
  - Příprava pro integraci s OpenCV, face_recognition knihovnou a vlastními ML modely

- **🔐 Inteligentní ovládání zámků (Lock Control)**
  - Přidán nový modul `lock_control.py` pro automatické akce
  - Při rozpoznání obličeje můžeš automaticky:
    - 🔓 **Odemknout dvěře**
    - 💡 **Rozsvítit světla** (např. ve vstupní chodbě)
    - 🚗 **Otevřít garážová vrata**
    - 📬 **Poslat notifikaci** (upozornění na mobil)
    - 🎬 **Spustit scénu** (např. "Příchod domů" — nastaví teplotu, zhasne alarm, apod.)
    - ⚙️ **Volat libovolnou Home Assistant službu**

- **⚙️ Nová nastavení v config_flow:**
  - Výběr kamer pro sledování (Face Recognition Cameras)
  - Práh jistoty pro rozpoznávání (0.0 - 1.0)
  - Výběr zámků na dveřích
  - Správa pravidel přístupu (Access Rules) — kdo má jakou právu

- **📖 Dokumentace:**
  - Nový dokument `FACE_RECOGNITION_GUIDE.md` — jak nastavit kamery a rozpoznávání
  - Nový dokument `LOCK_CONTROL_GUIDE.md` — jak automatizovat přístup na základě obličeje
  - Příklady v `example_config.yaml` — nastavení automatizací pro face recognition

- **🏠 Podpora Home Assistant 2024.7.0+**
  - Aktualizovány všechny vnitřní API callsy
  - Kompatibilita s novou verzí `helpers.llm`

### 🔧 ZMĚNY

- Config flow nyní nabízí duplex dialogu: jeden průvodce pro AI nastavení, druhý pro face recognition/lock control
- Interní struktura: odděleno na 3 nezávislé moduly (conversation, face_recognition, lock_control)

### 🐛 OPRAVY
- Vylepšena chybová hlášení při selhání spojení s Ollamou

### 📝 Poznámky

**Potřebné balíčky:**
- Pro face recognition bude v budoucnu: `opencv-python`, `face-recognition`
- Zatím jsou placeholdery — core integrace je připravená, ale detekce čeká na finální implementaci

**Bezpečnost:**
- Všechna data o obličejích zůstávají v lokální síti
- Žádné obrázky se neposílají do cloudu

---

## [1.0.0] - 2024-07-24

### 🆕 NOVÉ
- Počáteční vydání integrace AI Asistent (Ollama) pro Home Assistant
- Konverzační agent napojený na lokální Ollama server
- Podpora volání nástrojů Home Assistant (ovládání zařízení, čtení senzorů)
- Přepínatelný jazyk odpovědí (čeština, slovenština, angličtina, němčina,
  polština, ukrajinština, španělština, francouzština)
- Nastavitelný systémový prompt a kreativita odpovědí (temperature)
- Pamatuje si historii konverzace v rámci jednoho rozhovoru
- HACS kompatibilita (vlastní repozitář)
- Podporuje Home Assistant 2024.6.0+

### 🔒 BEZPEČNOST
- Bezpečné zpracování chyb — selhání spojení nebo nástroje nikdy neshodí HA
- Data zůstávají v lokální síti — bez posílání do cloudu

### Poznámka
- Pro ovládání zařízení nutný model s podporou tool calling (llama3.1, qwen2.5,
  mistral-nemo atd.)

---

[Nevydáno]: https://github.com/USER/ollama-ha-assistant/compare/1.0.0...HEAD
[1.0.0]: https://github.com/USER/ollama-ha-assistant/releases/tag/1.0.0
