# Přispívání do projektu

Děkujeme za zájem o přispívání! Jsme rádi za každou pomoc. Tady je pár zásad:

## Jak začít

1. **Forkni** repozitář na GitHubu.
2. **Klonuj** si jej lokálně:
   ```bash
   git clone https://github.com/TVÁ_JMÉNA/ollama-ha-assistant.git
   cd ollama-ha-assistant
   ```
3. **Vytvoř novou branch** pro svou funkci:
   ```bash
   git checkout -b feature/moje-nova-funkce
   ```

## Vývoj & testování

1. **Instaluj dev nástroje:**
   ```bash
   pip install ruff mypy
   ```

2. **Kontrola kódu před push:**
   ```bash
   ruff check custom_components/ollama_assistant/
   ruff format custom_components/ollama_assistant/
   python -m py_compile custom_components/ollama_assistant/*.py
   ```

3. **Testování v Home Assistant:**
   - Zkopíruj `custom_components/ollama_assistant/` do adresáře
     `config/custom_components/` tvé testovací HA instalace.
   - Restartuj HA, zkontroluj, že integrace načte bez chyb.

## Příspěvek: Pull Request

1. **Pushni** svou branch:
   ```bash
   git push origin feature/moje-nova-funkce
   ```

2. **Otevři Pull Request** na GitHubu s jasným názvem a popisem, co dělá a proč.

3. **Čekej na review** — GitHub Actions automaticky spustí testy (HACS, hassfest,
   linting). Pokud skončí s chybou, oprav ji a push znovu.

## Stylování kódu

- Používáme **Ruff** pro formátování a linting.
- Čeština v komentářích a docstringech je OK, ale Python identifikátory
  buď anglické (funkce, třídy, proměnné).
- Dodržuj existující styl kódu.

## Hlášení chyb

- Napiš issue s jasným názvem a kroky k reprodukci.
- Přilož logg Home Assistant (`config/home-assistant.log`).
- Uvedi verzi Home Assistant a Ollama.

## Otázky?

Napiš issue nebo se podívej na README — tam je víc kontextu.

Děkujeme! 🎉
