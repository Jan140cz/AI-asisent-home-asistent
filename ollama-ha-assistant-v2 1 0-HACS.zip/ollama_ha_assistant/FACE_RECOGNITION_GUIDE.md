# 🎥 Průvodce rozpoznáváním obličejů (Face Recognition)

Tato funkce umožňuje AI Asistentovi rozpoznat obličeje z kamer a na základě toho
provést automatické akce (odemknout dveře, rozsvítit světlo, apod.).

---

## Požadavky

### Hardware
- **Kamery** — alespoň jedna kamera, kterou má Home Assistant podporovat
  (IP kamera, USB kamera, Doorbell atd.)
- **Ollama server** — běžící s modelem (stejně jako u základní integrace)

### Software
- **Home Assistant 2024.7.0+**
- **AI Asistent (Ollama) verze 2.0.0+**
- V budoucnu: `opencv-python`, `face-recognition` (zatím nejsou povinné)

---

## Jak nastavit Face Recognition

### 1️⃣ Zajisti si kameru v Home Assistant

Nejdřív **musíš mít alespoň jednu kameru, kterou HA vidí**. Pokud máš IP kameru,
přidej si ji tímto způsobem:

**Nastavení → Zařízení a služby → Vytvořit automatizaci → Kamera**

Nebo pokud ji máš v YAML config:

```yaml
camera:
  - platform: mjpeg
    name: Vstupní dveře
    still_image_url: http://192.168.1.50:8080/video
```

Až bude kamera vidět (ověř v **Nastavení → Zařízení a služby → Kamery**), pokračuj.

### 2️⃣ Zapni Face Recognition v Možnostech integrace

1. Otevři **Nastavení → Zařízení a služby → AI Asistent (Ollama)**
2. Klikni na **Možnosti (Configure)**
3. Najdi sekci **Face Recognition:**
   - ✅ Zaškrtni **Zapni Face Recognition**
   - 📹 Vyber **Kamery** — které mají být sledovány
   - 🎯 Nastav **Práh jistoty** — doporučuji 0.7–0.8 (70–80%)
4. Uložit

### 3️⃣ (Budoucnost) Zaregistruj osoby do databáze obličejů

Prozatím je to placeholder, ale až bude implementováno, bude postup:

```bash
# Pošli snímek obličeje do asistenta
service: conversation.process
data:
  text: "Zaregistruj novou osobu: Petr"
  # Příloha: obrázek obličeje
```

Nebo přes web UI:
1. **Nastavení → Zařízení a služby → Služby** (Services)
2. Hledej `ollama_assistant.register_face`
3. Vlož jméno a obrázek

---

## Jak to funguje

```
┌─────────────┐
│   Kamera    │ ← snímek každých X sekund
└──────┬──────┘
       │
       ▼
┌──────────────────────┐
│  Face Recognition    │
│  (detekce obličejů)  │ ← hledáme obličeje
└──────────┬───────────┘
           │
           ▼
┌──────────────────────────┐
│  Porovnání se známými    │
│  obličeji (matching)     │ ← je to Petr? Jana? Někdo cizí?
└──────────┬───────────────┘
           │ Ano, je to Petr (jistota 95%)
           │
           ▼
┌──────────────────────────┐
│  Lock Control Engine     │
│  Hledá pravidla pro      │
│  "Petr"                  │ ← co se má stát?
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────┐
│  Spustí akce:            │
│  🔓 Odemkne dveře        │
│  💡 Rozsvítí předsíň     │
│  🎬 Spustí "Příchod domů"│
└──────────────────────────┘
```

---

## Nastavení pravidel přístupu (Access Rules)

Viz [LOCK_CONTROL_GUIDE.md](LOCK_CONTROL_GUIDE.md) — tam je podrobnější návod,
jak říct asistentovi, co má dělat, když rozpozná konkrétní osobu.

---

## Příklady — Co můžeš nastavit

### Příklad 1: Petr přijde domů

Když Face Recognition pozná Petra:
- 🔓 Odemkne hlavní dveře (`lock.main_door`)
- 💡 Rozsvítí předsíň (`light.hallway`)
- 🎬 Spustí scénu "Příchod domů" (nastaví teplotu na 21°C, zhasne alarm, apod.)

```yaml
# V LOCK_CONTROL_GUIDE.md je postup přes UI
# Zde příklad konfigurace
access_rules:
  - person: "Petr"
    actions:
      - type: "unlock"
        target: "lock.main_door"
      - type: "turn_on_light"
        target: "light.hallway"
      - type: "scene"
        target: "scene.come_home"
```

### Příklad 2: Cizinec byl detekován

Když Face Recognition pozná **neznámého člověka:**
- 📬 Pošle notifikaci majiteli
- 🔒 Zavře všechny dveře
- 🎥 Nahraje video z bezpečnostní kamery

```yaml
access_rules:
  - person: "UNKNOWN"  # Special value — neznámé obličeje
    actions:
      - type: "notification"
        message: "⚠️ Neznámá osoba detekována u dveří!"
      - type: "lock"
        target: "lock.main_door"
      - type: "service_call"
        service: "script.record_security_camera"
```

### Příklad 3: Návštěva v určitém čase

Pravidlo se spustí jenom, pokud je určitý čas:

```yaml
access_rules:
  - person: "Návštěva"
    conditions:
      - time_start: "14:00"
        time_end: "18:00"
      - days: ["Monday", "Wednesday", "Friday"]
    actions:
      - type: "unlock"
        target: "lock.guest_entrance"
```

---

## Bezpečnost a soukromí 🔒

### Kde se data ukládají?
- **Pouze v lokální síti** — žádné obrázky se neposílají na cloud
- Databáze obličejů zůstává v Home Assistant

### Kdo má přístup?
- Řídí se Home Assistant oprávněními — pokud máš admin přístup k HA, máš přístup k registrovaným obličejům

### Jak smazat obličej z databáze?

```bash
service: ollama_assistant.unregister_face
data:
  person_name: "Petr"
```

---

## Řešení problémů

| Problém | Řešení |
|---------|--------|
| Face Recognition nepracuje | Zkontroluj, že je **zapnuto** v Možnostech integrace |
| Kamera není dostupná | Ujisti se, že kamera je přidaná do HA a funguje (**Nastavení → Zařízení a služby → Kamery**) |
| Obličej není rozpoznán, ač je osoba registrovaná | Zvýš JPEG kvalitu na kameře nebo sníž práh jistoty (0.5–0.6) |
| Asistent pozná špatně (matení s někým jiným) | Zvýš práh jistoty (0.8–0.9) — bude přísněji |
| Chyba: "Modul face_recognition se nenačetl" | Instaluj: `pip install face-recognition opencv-python` (bude v budoucích verzích automatické) |

---

## Budoucí funkce

- 🤖 **Deep Learning** — vlastní ML model pro lepší rozpoznávání
- 🔔 **Upozornění na cizince** — automaticky upozorní, když je detekován neznámý obličej
- 📊 **Statistiky** — kolik krát byla kterou osoba rozpoznána, kdy apod.
- 🎭 **Věk a pohlaví** — asistent bude schopen rozpoznat přibližný věk a pohlaví (ale pořád bez identifikace)
- 🌍 **Multi-kamera** — tracking osoby mezi více kamerami

---

*Viz také: [LOCK_CONTROL_GUIDE.md](LOCK_CONTROL_GUIDE.md) — jak nastavit akce*
*Technické detaily: [Kód v `face_recognition.py`](custom_components/ollama_assistant/face_recognition.py)*
