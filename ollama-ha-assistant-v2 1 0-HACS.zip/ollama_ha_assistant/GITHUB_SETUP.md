# Příprava GitHub repozitáře pro HACS

Tady je krok za krokem návod, jak nastavit GitHub repozitář tak, aby přijalo
HACS.

## 1. Vytvoření GitHub repozitáře

1. Jdi na [github.com](https://github.com) a přihlaš se.
2. Klikni na **+** v pravém horním rohu → **New repository**.
3. **Repository name:** `ollama-ha-assistant`
4. **Description:** `AI Asistent (Ollama) pro Home Assistant — konverzační agent napojený na lokální AI model`
5. Vyber **Public** (HACS vyžaduje public repozitář).
6. **Initialize this repository with:**
   - ✓ Add a README file — nemusíš, máš už README.md
   - ✓ Add .gitignore — máš už .gitignore
   - ✓ Choose a license — máš už LICENSE
7. Klikni **Create repository**.

## 2. Clone a push souborů

```bash
# Klonuj si nový repozitář
git clone https://github.com/TVOJE_JMENO/ollama-ha-assistant.git
cd ollama-ha-assistant

# Zkopíruj všechny soubory z připravené struktury
cp -r /cesta/k/ollama_ha_assistant/* .

# Git setup
git add .
git commit -m "Initial commit: AI Asistent (Ollama) integration"
git push origin main
```

## 3. Nastavení GitHub repozitáře

### 3a. Branch protection (volitelné, ale doporučené)

1. Jdi do **Settings → Branches**.
2. Pod "Branch protection rules" klikni **Add rule**.
3. **Branch name pattern:** `main`
4. Zaškrtni:
   - ✓ Require a pull request before merging
   - ✓ Require status checks to pass before merging
   - ✓ Require branches to be up to date before merging
5. Klikni **Create**.

### 3b. GitHub Actions (už máš nastavené v .github/workflows/)

Zkontroluj, že Actions běží:
1. Jdi do **Actions** záložky.
2. Měly by běžet "Validace kódu", "HACS validace" a "Home Assistant validace".
3. Pokud některá selhala, klikni na ni a podívej se na log.

## 4. Vytvoření prvního Release

```bash
# Vytvoř tag pro verzi 1.0.0
git tag 1.0.0 -m "Initial release: AI Asistent (Ollama) v1.0.0"
git push origin 1.0.0
```

Na GitHubu:
1. Jdi do **Releases** (pravá strana).
2. Měl by se objevit **1.0.0** tag.
3. Klikni na něj a **Edit release**.
4. Vyplň release notes (seberou se z CHANGELOG.md).
5. Klikni **Publish release**.

## 5. Přidání do HACS

1. V Home Assistant otevři **HACS**.
2. Klikni vpravo nahoře tři tečky → **Vlastní repozitáře / Custom repositories**.
3. Vlož:
   - **URL:** `https://github.com/TVOJE_JMENO/ollama-ha-assistant`
   - **Category:** Integration
4. Potvrď.
5. Měl by se objevit "AI Asistent (Ollama)" v seznamu integrací v HACS.

**Alternativně:** Pokud chceš, aby bylo vidět v oficiálním HACS, napiš issue
v [HACS/default](https://github.com/hacs/default) s linkem na svůj repozitář.

## 6. GitHub Topics (pro SEO a discovery)

1. Jdi do **Settings → General** (nahoře).
2. Scroluj dolů na "Repository topics".
3. Přidej:
   - `home-assistant`
   - `hacs`
   - `integration`
   - `ollama`
   - `ai`
   - `assistant`

## 7. GitHub Pages (volitelné - pro lepší dokumentaci)

1. Jdi do **Settings → Pages**.
2. **Source** nastav na "Deploy from a branch".
3. Vyber branch `main` a folder `/ (root)`.
4. Klikni **Save**.
5. Za chvilku ti bude dokumentace dostupná na `https://TVOJE_JMENO.github.io/ollama-ha-assistant/`

## Ověření, že je všechno OK

Spusť si lokálně HACS validátor:
```bash
pip install hacs-cli
hacs-cli validate .
```

Mělo by skončit bez chyb.

## Troubleshooting

- **HACS nedokáže najít repozitář:** Zkontroluj, že je PUBLIC a že URL je správná.
- **Validace selhává:** Podívej se na log GitHub Actions, co přesně se nepovedlo.
- **manifest.json chybí:** Musí být na cestě `custom_components/ollama_assistant/manifest.json`.
- **hacs.json chybí:** Musí být v rootu repozitáře na cestě `hacs.json`.

## Publikace v HACS Store (oficiální)

Když je vše hotovo a testováno:
1. Otevři issue v [HACS/default](https://github.com/hacs/default/issues/new/choose).
2. Vyber "New integration".
3. Vyplň formulář a pošli.
4. HACS team se podívá a schválí/zamítne.

Gratulujeme! 🎉
