# HACS Checklist ✅

Před tím, než si pošleš integraci do HACS, zkontroluj si tohle:

## Struktura repozitáře

- [ ] Repozitář je **public** na GitHubu
- [ ] Soubory jsou v UTF-8 (bez BOM)
- [ ] Nemáš v gitu `__pycache__/`, `.pyc`, `.env` apod. (máš `.gitignore`? ✓)

## Povinné soubory v root adresáři

- [ ] **`hacs.json`** — metadata repozitáře
  ```json
  {
    "name": "AI Asistent (Ollama)",
    "render_readme": true,
    "homeassistant": "2024.6.0"
  }
  ```
- [ ] **`LICENSE`** — MIT, Apache, GPL apod.
  - Máš: `LICENSE` (MIT) ✓
- [ ] **`README.md`** — alespoň popis co to je
  - Máš ✓

## Integrace — `custom_components/ollama_assistant/`

- [ ] **`manifest.json`** s těmito klíči:
  ```json
  {
    "domain": "ollama_assistant",
    "name": "AI Asistent (Ollama)",
    "codeowners": [],
    "config_flow": true,
    "dependencies": [],
    "documentation": "https://github.com/GITHUB_UŽIVATEL/ollama-ha-assistant",
    "integration_type": "service",
    "iot_class": "local_polling",
    "issue_tracker": "https://github.com/GITHUB_UŽIVATEL/ollama-ha-assistant/issues",
    "requirements": ["ollama>=0.3.0"],
    "version": "1.0.0"
  }
  ```
- [ ] **`__init__.py`** — async_setup_entry, async_unload_entry
- [ ] **`config_flow.py`** — config flow (volitelné, ale doporučené)
- [ ] **`strings.json`** — texty pro UI
- [ ] Žádné Python syntax chyby (`python -m py_compile *.py` ✓)

## Validace

Spusť lokálně HACS validátor:
```bash
pip install hacs-cli
hacs-cli validate .
```

Mělo by skončit bez chyb. Pokud jsou chyby, oprav je.

## GitHub Actions (nepovinné, ale hodí se)

- [ ] Máš `.github/workflows/` s validačními workflow?
  - `validate.yml` — linting, type checking
  - `hacs.yml` — HACS validace
  - `hassfest.yml` — Home Assistant validace

Pokud máš GitHub Actions, měly by všechny skončit bez chyb.

## GitHub nastavení

- [ ] **Repozitář topics:** `home-assistant`, `hacs`, `integration`
  - (Settings → General → Topics)
- [ ] **Licence:** MIT (nebo jiná open-source)
- [ ] **Branch protection** (volitelné):
  - Require status checks to pass before merging

## Kód

- [ ] Bez hardcodovaných API klíčů, hesel, tokenů
- [ ] Bez velkých binarních souborů (obrázky, data)
- [ ] Python kód je aspoň základně čitelný (formátování, komentáře)

## Dokumentace

- [ ] `README.md` vysvětluje:
  - Co to je a co umí
  - Jak se instaluje
  - Jak se nastavuje
- [ ] Případně další markdown soubory (`CONTRIBUTING.md`, `CHANGELOG.md`)

## Vydání verze (Release)

Než posleš do HACS:
1. [ ] Měl by být aspoň jeden **release/tag** v GitHubu
   ```bash
   git tag 1.0.0
   git push origin 1.0.0
   ```
2. [ ] GitHub by měl mít vidět **Release** v sekci Releases
3. [ ] Verze v tagu by se měla shodovat s verzí v `manifest.json`

## Podání do HACS

Až je všechno hotovo:
1. [ ] Jdi na https://github.com/hacs/default/issues/new?template=new_integration.yml
2. [ ] Vyplň formulář:
   - Repository URL: `https://github.com/TVOJE_JMENO/ollama-ha-assistant`
   - Krátký popis
   - Odkaz na dokumentaci
3. [ ] Pošli issue
4. [ ] Čekej na review HACS team (obvykle pár dní)

## FAQ

**Q: Co když HACS validace selhá?**
A: Podívej se na hlášku chyby, oprav problém a zkus znovu.

**Q: Jakou verzi Home Assistant mám podpořit?**
A: Minimálně `2024.6.0` (v tom je nový conversation API). Starší verze nejsu
   podporovány.

**Q: Jak nastavím codeowners?**
A: V `manifest.json` pole `codeowners` = lista GitHub uživatelských jmen:
   ```json
   "codeowners": ["@tvoje_jmeno"]
   ```

**Q: Co když se mi nechce čekat na schválení HACS?**
A: Můžeš taky říci lidem, aby si přidali repozitář jako "Custom repository"
   v HACS manualně — bez čekání na schválení.

---

**Hotovo?** → Gratuluji! 🎉 Ať se tvému asistentovi daří!
