# 🔐 Průvodce inteligentním odemykáním (Lock Control)

Tento modul umožňuje automaticky ovládat zámky, světla a další zařízení **na základě
rozpoznaného obličeje**. Když Face Recognition rozpozná osobu, automaticky se spustí
předvolené akce — např. odemknutí dveří, rozsvícení světel, spuštění scény "Příchod domů".

---

## Co se dá dělat s Lock Control?

| Akce | Popis | Cíl |
|------|-------|-----|
| 🔓 **Odemknout dvěře** | Automaticky odemkne zámek | `lock.nazev_zamku` |
| 🔒 **Zamknout dvěře** | Automaticky zamkne zámek | `lock.nazev_zamku` |
| 💡 **Rozsvítit světlo** | Zapne světlo | `light.nazev_svetla` |
| 🌙 **Zhasnout světlo** | Vypne světlo | `light.nazev_svetla` |
| 🚗 **Otevřít garáž** | Otevře garážová vrata | `cover.garage` |
| 📬 **Poslat notifikaci** | Pošle zprávu na mobil | `notify.mobile_app_xxx` |
| 🎬 **Spustit scénu** | Spustí předvolený scénář | `scene.prijchod_domu` |
| ⚙️ **Zavolat službu** | Zavolá jakoukoliv HA službu | libovolná |

---

## Jak nastavit pravidla přístupu

### Krok 1: Máš kamery a zámky připravené?

Předpoklady:
- ✅ **Kamera** — vidí se v **Nastavení → Zařízení a služby → Kamery**
- ✅ **Zámek** — vidí se v **Nastavení → Zařízení a služby → Zamykatelné zařízení (Locks)**

### Krok 2: Vyber kamery a zámky v Možnostech integrace

1. **Nastavení → Zařízení a služby → AI Asistent (Ollama) → Možnosti**
2. Doplň:
   - **Face Recognition Cameras** — vyber kamery na dveřích
   - **Lock Entities** — vyber zámky na dveřích
3. Uložit

### Krok 3: Vytvoř pravidlo přístupu

Prozatím je to ruční konfiguraci v YAML (UI bude v budoucnu):

```yaml
# configuration.yaml nebo automation.yaml

# Příklad 1: Petr se přiblíží — dveře se odemknou
automation:
  - id: "petra_odemyka_dvere"
    alias: "Petr: Odemkni dveře"
    trigger:
      platform: state
      entity_id: sensor.ollama_recognized_person
      to: "Petr"
    action:
      service: lock.unlock
      data:
        entity_id: lock.main_door

# Příklad 2: Petr se přiblíží — složitější scénář
automation:
  - id: "petra_prijchod_domu"
    alias: "Petr: Příchod domů"
    trigger:
      platform: state
      entity_id: sensor.ollama_recognized_person
      to: "Petr"
    action:
      - service: lock.unlock
        data:
          entity_id: lock.main_door
      - service: light.turn_on
        data:
          entity_id: light.hallway
          brightness: 255
      - service: scene.turn_on
        data:
          entity_id: scene.welcome_home
      - service: notify.mobile_app_petr_telefon
        data:
          title: "👋 Vítej doma!"
          message: "Dveře byly odemčeny a světla zapnuta"
```

---

## Praktické příklady

### ✅ Příklad 1: Jednoduchý případ — Jana přijde domů

**Co se stane:**
- Jana je vidět v kameře
- Face Recognition ji pozná
- Dveře se odemknou
- Světlo se rozsvítí

```yaml
automation:
  - alias: "Jana: Odemkni a rozsvítí"
    trigger:
      platform: state
      entity_id: sensor.face_recognition_detected
      to: "Jana"
    action:
      - service: lock.unlock
        data:
          entity_id: lock.main_door
      - service: light.turn_on
        data:
          entity_id:
            - light.hallway
            - light.living_room
```

### ✅ Příklad 2: Nastavitelný čas — návštěva v určitou dobu

**Scénář:** Kadeřnice doleva vždy v úterý a čtvrtek od 14:00 do 16:00.
V tu dobu se mají odemknout jen zadní dveře.

```yaml
automation:
  - alias: "Kadeřnice: Odemkni zadní dveře"
    trigger:
      platform: state
      entity_id: sensor.face_recognition_detected
      to: "Kadeřnice"
    condition:
      - condition: time
        weekday:
          - "tue"
          - "thu"
        after: "14:00"
        before: "16:00"
    action:
      service: lock.unlock
      data:
        entity_id: lock.back_door
```

### ✅ Příklad 3: Cizinec — upozorni a zavři

**Scénář:** Když je detekován neznámý obličej, pošli notifikaci a zavři všechny dveře.

```yaml
automation:
  - alias: "BEZPEČNOST: Neznámá osoba!"
    trigger:
      platform: state
      entity_id: sensor.face_recognition_detected
      to: "UNKNOWN"
    action:
      - service: notify.mobile_app_admin
        data:
          title: "🚨 BEZPEČNOSTNÍ UPOZORNĚNÍ"
          message: "Neznámá osoba detekována u dveří!"
      - service: lock.lock
        data:
          entity_id:
            - lock.main_door
            - lock.back_door
            - lock.garage
      - service: script.start_recording_security_camera
```

### ✅ Příklad 4: Spuštění složité scény

**Scénář:** Když se manželka vrátí z práce, spusť scénu "Příchod domů" (teplota na 21°C,
zhasni alarm, nainstaluj si Coffee maker, apod.)

```yaml
automation:
  - alias: "Příchod domů: Aktivuj scénu"
    trigger:
      platform: state
      entity_id: sensor.face_recognition_detected
      to: "Manželka"
    action:
      - service: scene.turn_on
        data:
          entity_id: scene.come_home_evening

# Definice scény:
scene:
  - name: "Příchod domů"
    entities:
      light.living_room:
        state: on
        brightness: 200
      light.hallway:
        state: on
      climate.termostat:
        temperature: 21
      alarm_control_panel.alarm:
        state: disarmed
      switch.coffee_maker:
        state: on
```

### ✅ Příklad 5: Multi-osoba — různé akce pro různé lidi

```yaml
automation:
  - alias: "Osobní prvky: Různé akce"
    trigger:
      platform: state
      entity_id: sensor.face_recognition_detected
    action:
      - choose:
          # Petr
          - conditions:
              - condition: state
                entity_id: sensor.face_recognition_detected
                state: "Petr"
            sequence:
              - service: light.turn_on
                data:
                  entity_id: light.study  # Zapne lampu v pracovně
              - service: switch.turn_on
                data:
                  entity_id: switch.computer_monitor
              
          # Jana
          - conditions:
              - condition: state
                entity_id: sensor.face_recognition_detected
                state: "Jana"
            sequence:
              - service: light.turn_on
                data:
                  entity_id: light.kitchen  # Zapne lampu v kuchyni
              - service: switch.turn_on
                data:
                  entity_id: switch.kitchen_music  # Spustí hudbu
              
          # Dítě
          - conditions:
              - condition: state
                entity_id: sensor.face_recognition_detected
                state: "Malý_Honza"
            sequence:
              - service: light.turn_on
                data:
                  entity_id: light.kids_room
                  brightness: 100  # Méně světla pro oči
```

---

## Pokročilé: Podmínky a logika

### Odemkni JENOM pokud je tma

```yaml
automation:
  - alias: "Odemkni, pokud je tma"
    trigger:
      platform: state
      entity_id: sensor.face_recognition_detected
      to: "Petr"
    condition:
      - condition: numeric_state
        entity_id: sensor.light_level
        below: 50  # Jenom pokud je osvětlení nižší než 50
    action:
      service: lock.unlock
      data:
        entity_id: lock.main_door
```

### Odemkni JENOM pokud nejsi v práci

```yaml
automation:
  - alias: "Odemkni, pokud se nejedná o pracovní dobu"
    trigger:
      platform: state
      entity_id: sensor.face_recognition_detected
      to: "Petr"
    condition:
      - condition: time
        weekday:
          - "sat"
          - "sun"
        # Nebo: before: "09:00" (před 9. hodinou v pracovní dny)
    action:
      service: lock.unlock
      data:
        entity_id: lock.main_door
```

### Odemkni s potvrzením (pokud nejsi doma)

```yaml
automation:
  - alias: "Požádej o potvrzení pro odemknutí"
    trigger:
      platform: state
      entity_id: sensor.face_recognition_detected
      to: "Cizinec"  # Neznámá osoba
    condition:
      - condition: state
        entity_id: person.owner_location
        state: "not_home"  # Majitel není doma
    action:
      - service: notify.mobile_app_owner
        data:
          title: "🔓 Žádost o odemknutí"
          message: "Cizinec chce vstoupit. Odemknout?"
          data:
            actions:
              - action: "open_door"
                title: "Ano, odemkni"
              - action: "deny"
                title: "Ne, zavři"
      # (V budoucnu: čekat na odpověď)
```

---

## Bezpečnostní doporučení 🔒

1. **Vysoká jistota pro odemykání** — nastav práh na 0.85+ pro odemykání dveří
   (v `FACE_RECOGNITION_CONFIDENCE`)
2. **Záznam akcí** — měj v logu záznamy o každém odemknutí
3. **Backup přístup** — vždy měj fyzickou klíčenku nebo kód, kdyby Face Recognition selhala
4. **Test v bezpečném prostředí** — nejdřív zkus automatizaci jen se světlem,
   později s dveřmi
5. **Upozornění majiteli** — vždy pošli notifikaci, když se něco odemkne

---

## Řešení problémů

| Problém | Řešení |
|---------|--------|
| Automatizace se nespustí | Zkontroluj, že sensor `face_recognition_detected` existuje a že se změní stav (viz logs) |
| Dveře se odemknou, ale světlo ne | Některá zařízení může mít zpoždění — přidej `delay: "00:00:02"` mezi akce |
| Chci zrušit odemknutí | Přidej druhé pravidlo: `trigger: ... to: "nobody"` — zavírá, když nikdo není |
| Zámek se neodemkl | Zkontroluj, že zámek je v YAML konfigu v `lock:` domény |

---

## Integrační tipy s ostatními automation

### S Home Assistant Person

```yaml
# Automaticky se zamkne, když všichni odejdou
automation:
  - alias: "Zavři při odchodu všech"
    trigger:
      platform: state
      entity_id: person.owner, person.spouse
      to: "not_home"
    action:
      service: lock.lock
      data:
        entity_id: lock.main_door
```

### S Google Assistant / Alexa

```yaml
# Vypusť hlasový příkaz do Face Recognition
automation:
  - alias: "Hlasem odemkni dveře"
    trigger:
      platform: event
      event_type: google_assistant_request
      event_data:
        command: "odemkni"
    action:
      # Spustí Face Recognition
      service: conversation.process
      data:
        text: "Odemkni dveře"
        agent_id: "conversation.ollama_assistant"
```

---

*Viz také: [FACE_RECOGNITION_GUIDE.md](FACE_RECOGNITION_GUIDE.md) — jak nastavit kamery*
*Technické detaily: [Kód v `lock_control.py`](custom_components/ollama_assistant/lock_control.py)*
