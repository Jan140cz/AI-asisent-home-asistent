# AI Asistent (Ollama) pro Home Assistant

[![HACS Custom][hacs-badge]][hacs-url]
[![GitHub Release][release-badge]][release-url]
[![GitHub License][license-badge]][license-url]
[![Validate with hassfest][validate-badge]][validate-url]

Konverzační agent do Home Assistant, který odpovídá pomocí **lokálního AI modelu
přes Ollama** (žádná data neopouští tvou síť) a umí podle potřeby ovládat
zařízení v domácnosti (rozsvítit, zhasnout, zjistit stav senzoru apod.), pokud
to zapneš v nastavení.

---

## 🚀 Rychlá instalace (HACS)

[![Open your Home Assistant instance and open a repository inside the Home Assistant Community Store.][open-hacs-badge]][open-hacs-url]

Nebo ručně:
1. HACS → Vlastní repozitáře → přidej `https://github.com/USER/ollama-ha-assistant`
2. HACS → AI Asistent (Ollama) → Nainstaluj
3. Restartuj Home Assistant

---

## Co to umí

- Odpovídá na dotazy pomocí modelu běžícího na tvém vlastním Ollama serveru.
- Umí (volitelně) volat nástroje Home Assistant a plnit úkoly – ovládat
  zařízení, která máš vystavená v Assistu.
- Jde nastavit **jazyk odpovědí** (čeština, slovenština, angličtina, němčina,
  polština, ukrajinština, španělština, francouzština) i osobnost/systémový
  prompt asistenta.
- Je napsaný tak, aby chyba spojení s Ollamou nebo selhání nástroje **nikdy
  neshodilo Home Assistant** – asistent v takovém případě jen slušně odpoví,
  že se něco nepovedlo, a napíše to i do logu.

## Požadavky

- Běžící [Ollama](https://ollama.com) server dostupný ze sítě, kde běží Home
  Assistant (lokálně, na NAS, na jiném PC v síti…).
- Stažený model, např.:

  ```bash
  ollama pull llama3.1
  ```

  Pro ovládání zařízení (volání nástrojů) potřebuješ model s podporou *tool
  calling* – funguje např. `llama3.1`, `qwen2.5`, `mistral-nemo`. Menší modely
  bez podpory nástrojů budou fungovat jen jako konverzace bez ovládání.

## Instalace přes HACS (vlastní repozitář)

1. V Home Assistant otevři **HACS**.
2. Klikni vpravo nahoře na tři tečky → **Vlastní repozitáře / Custom
   repositories**.
3. Vlož URL tohoto GitHub repozitáře, kategorii nastav na **Integrace /
   Integration**, potvrď.
4. Najdi v HACS „AI Asistent (Ollama)“ a nainstaluj.
5. Restartuj Home Assistant.

## Nastavení integrace

1. **Nastavení → Zařízení a služby → Přidat integraci → AI Asistent
   (Ollama)**.
2. Zadej adresu Ollama serveru (např. `http://192.168.1.10:11434`) a název
   modelu (např. `llama3.1`).
3. Po dokončení klikni na integraci → **Možnosti / Configure**, kde nastavíš:
   - **Jazyk odpovědí** – jazyk, ve kterém má asistent vždy odpovídat.
   - **Systémový prompt** – osobnost a chování asistenta.
   - **Kreativitu (teplotu)** odpovědí.
   - **Ovládání zařízení Home Assistant** – vyber API (typicky „Assist“),
     aby asistent mohl plnit úkoly v domácnosti. Nezapomeň v
     **Nastavení → Hlasové ovládání → Vystavené entity** povolit entity,
     které má asistent umět ovládat.
4. V **Nastavení → Hlasové ovládání (Voice assistants)** vyber tohoto agenta
   jako konverzačního agenta pro Assist, případně ho použij v automatizacích
   přes službu `conversation.process`.

## Aktualizace a novinky

- Historie verzí a co se v každé změnilo: [CHANGELOG.md](CHANGELOG.md).
- Návod na bezpečnou aktualizaci (a co dělat, pokud po ní integrace nenaběhne):
  [UPGRADE_GUIDE.md](UPGRADE_GUIDE.md).
- HACS tě na novou verzi upozorní automaticky v postranním panelu. Pokud
  chceš dostat i notifikaci přímo do mobilu / na displej, použij hotovou
  automatizaci z [`notification.yaml`](notification.yaml).

## Poznámka k verzím Home Assistant

Integrace používá interní API Home Assistant pro nástroje LLM (`llm.async_get_api`,
`llm.APIInstance`), které se občas mezi verzemi mírně mění. Pokud po aktualizaci
Home Assistant uvidíš v logu chybu při načítání nástrojů, zkontroluj changelog
jádra HA pro modul `helpers.llm` a uprav `conversation.py` podle aktuálního API.

---

## 🎥 Rozpoznávání obličejů a inteligentní odemykání (Verze 2.0.0+)

Od verze 2.0.0 má integrace podporu pro:

- **🎥 Face Recognition** — rozpoznávání obličejů z kamer
- **🔐 Lock Control** — automatické odemykání dveří na základě obličeje
- **💡 Inteligentní domácnost** — spouštění scén, světel a služeb

Podrobné návody:
- **[FACE_RECOGNITION_GUIDE.md](FACE_RECOGNITION_GUIDE.md)** — jak nastavit kamery a detekci
- **[LOCK_CONTROL_GUIDE.md](LOCK_CONTROL_GUIDE.md)** — jak automatizovat dveře a ostatní zařízení
- **[UPGRADE_GUIDE.md#200---2024-07-25](UPGRADE_GUIDE.md)** — jak upgradovat ze staré verze

Příklady v `example_config.yaml` — sekce „Face Recognition Examples".

---

## Vývoj & Přispívání

Podívej se na [CONTRIBUTING.md](CONTRIBUTING.md) pro informace o tom, jak
přispět do projektu.

Pro vývoj a testování máme připraveno:
- `requirements-dev.txt` — dev závislosti
- `Makefile` — běžné příkazy (`make lint`, `make format`, atd.)
- `docker-compose.yml` — Ollama server v Dockeru pro testování
- GitHub Actions pro automatické testy (validace, linting, Home Assistant checks)

**Nastavit si GitHub repozitář pro HACS?**
→ [GITHUB_SETUP.md](GITHUB_SETUP.md)

## Licence

MIT — viz [LICENSE](LICENSE)

---

<!-- Badge definitions -->
[hacs-badge]: https://img.shields.io/badge/HACS-Custom-41BDF5?style=flat-square
[hacs-url]: https://github.com/hacs/integration
[release-badge]: https://img.shields.io/github/v/release/USER/ollama-ha-assistant?style=flat-square
[release-url]: https://github.com/USER/ollama-ha-assistant/releases
[license-badge]: https://img.shields.io/github/license/USER/ollama-ha-assistant?style=flat-square
[license-url]: https://github.com/USER/ollama-ha-assistant/blob/main/LICENSE
[validate-badge]: https://github.com/USER/ollama-ha-assistant/actions/workflows/validate.yml/badge.svg
[validate-url]: https://github.com/USER/ollama-ha-assistant/actions/workflows/validate.yml
[open-hacs-badge]: https://my.home-assistant.io/badges/hacs_repository.svg
[open-hacs-url]: https://my.home-assistant.io/redirect/hacs_repository/?owner=USER&repository=ollama-ha-assistant&category=integration
