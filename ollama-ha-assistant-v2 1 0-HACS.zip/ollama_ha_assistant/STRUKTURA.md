# Struktura repozitáře

Tady je přehled, co která složka/soubor obsahuje:

## 📂 Hlavní struktura

```
ollama-ha-assistant/
├── .github/                          # GitHub specifika
│   ├── ISSUE_TEMPLATE/              # Šablony pro issues
│   │   ├── bug_report.md
│   │   └── feature_request.md
│   ├── workflows/                    # GitHub Actions CI/CD
│   │   ├── validate.yml             # Linting a syntax checks
│   │   ├── hacs.yml                 # HACS validace
│   │   └── hassfest.yml             # Home Assistant validace
│   └── pull_request_template.md      # Šablona pro PR
│
├── custom_components/ollama_assistant/  # 🔴 INTEGRACE
│   ├── __init__.py                  # Entry point + setup
│   ├── const.py                     # Konstanty (jazyky, defaults)
│   ├── config_flow.py               # Config UI (onboarding + options)
│   ├── conversation.py              # Hlavní agent (napojení na Ollamu)
│   ├── manifest.json                # Metadata integrace pro HA
│   ├── strings.json                 # Texty pro UI (výchozí/CZ)
│   └── translations/                # Překlady
│       ├── cs.json                  # Čeština
│       └── en.json                  # Angličtina
│
├── tests/                           # Unit testy
│   ├── __init__.py
│   └── test_const.py               # Testy pro constants
│
├── .gitignore                       # Git ignore rules
├── CHANGELOG.md                     # Changelog verzí
├── CONTRIBUTING.md                  # Jak přispívat
├── docker-compose.yml               # Docker Compose pro Ollamu
├── example_config.yaml              # Příklady automatizací v HA
├── GITHUB_SETUP.md                  # Návod na GitHub setup
├── GITHUB_SETUP.md                  # 📘 NÁVOD NA GITHUB NASTAVENÍ
├── STRUKTURA.md                     # 👈 Tento soubor
├── hacs.json                        # HACS metadata
├── LICENSE                          # MIT License
├── Makefile                         # Dev příkazy
├── README.md                        # Hlavní dokumentace
└── requirements-dev.txt             # Dev Python dependencies
```

## 🔴 Integrace — `custom_components/ollama_assistant/`

To je jádro projektu. Home Assistant si automaticky načte z tohoto adresáře.

### Klíčové soubory:

- **`manifest.json`** — Metadata: verze, závislosti, ikona (Home Assistant to čte).
- **`__init__.py`** — Setup integrace (async_setup_entry, async_unload_entry).
- **`const.py`** — Konstanty: názvy domén, jazyky, výchozí hodnoty.
- **`config_flow.py`** — Config UI: průvodce prvotním nastavením + možnosti.
- **`conversation.py`** — **Nejdůležitější:** Samotný agent (komunikace s Ollamou,
  volání nástrojů HA).
- **`strings.json`** — Textové řetězce pro UI (čeština, angličtina).
- **`translations/`** — Překlady strings.json do dalších jazyků.

## 📘 GitHub & CI/CD

- **`.github/workflows/`** — Automatické testy na каждый push/PR:
  - `validate.yml` — Python linting (Ruff), type checking (mypy).
  - `hacs.yml` — HACS validace struktury.
  - `hassfest.yml` — Home Assistant manifest validation.
- **`.github/ISSUE_TEMPLATE/`** — Standardní formuláře pro issues.
- **`pull_request_template.md`** — Šablona pro pull requesty.

## 🧪 Testování

- **`tests/`** — Unit testy (PyTest).
  - `test_const.py` — Testy na konstanty.
  - Lze přidat další `test_*.py` soubory.
- **`requirements-dev.txt`** — Dependencies pro development (Ruff, mypy, pytest).
- **`Makefile`** — Zkrácené příkazy: `make lint`, `make format`, atd.

## 🐳 Docker

- **`docker-compose.yml`** — Spustí Ollama server pro testování bez instalace.
  ```bash
  docker-compose up -d
  docker exec ollama-assistant-test ollama pull llama3.1
  ```

## 📝 Dokumentace

- **`README.md`** — Hlavní dokumentace pro uživatele.
- **`GITHUB_SETUP.md`** — Návod na vytvoření GitHub repozitáře + HACS.
- **`CONTRIBUTING.md`** — Jak přispívat do projektu.
- **`CHANGELOG.md`** — Verze a co se změnilo.
- **`STRUKTURA.md`** — Tento soubor 😉
- **`example_config.yaml`** — Příklady nastavení Home Assistant.

## 🔑 Klíčové cesty pro HACS

HACS hledá:
1. **`hacs.json`** v root adresáři (metadata repozitáře).
2. **`custom_components/ollama_assistant/manifest.json`** (metadata integrace).
3. **`LICENSE`** (musí být v root).
4. **`README.md`** (musí být v root).

Pokud některý z těchto souborů chybí, HACS repozitář neschválí! ⚠️

## 📦 Release / Vydání nové verze

1. Aktualizuj verzi v `manifest.json` a `CHANGELOG.md`.
2. Vytvoř Git tag: `git tag 1.0.1`.
3. Push tag: `git push origin 1.0.1`.
4. GitHub automaticky vytvoří Release ze tagu.
5. HACS si ji později stáhne a nabídne uživatelům.

## 🚀 Pro vývojáře

```bash
# Setup
git clone https://github.com/YOUR/ollama-ha-assistant.git
cd ollama-ha-assistant
make install

# Vývoj
make lint      # Kontrola kódu
make format    # Formátování
make validate  # Syntax check
make clean     # Smazat cache

# Test s Docker
docker-compose up -d
# Teď běží Ollama na http://localhost:11434
```

## 🎯 Shrnutí pro přidání do HACS

Aby integrace prošla HACS validací:
- ✅ `hacs.json` v root (máš ✓)
- ✅ `custom_components/ollama_assistant/manifest.json` (máš ✓)
- ✅ `LICENSE` v root (máš ✓)
- ✅ `README.md` v root (máš ✓)
- ✅ Repozitář je public na GitHubu (musíš)
- ✅ Soubory jsou UTF-8 (jsou ✓)
- ✅ Bez __pycache__ a .pyc v gitu (máš .gitignore ✓)

Viz [GITHUB_SETUP.md](GITHUB_SETUP.md) pro detaily.
