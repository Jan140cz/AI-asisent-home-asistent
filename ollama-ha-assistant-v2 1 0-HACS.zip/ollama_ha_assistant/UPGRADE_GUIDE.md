# 🔄 Průvodce aktualizací (Upgrade Guide)

Tento soubor popisuje, jak bezpečně aktualizovat integraci AI Asistent (Ollama)
a na co si dát pozor u jednotlivých verzí. Vždy si nejdřív přečti sekci pro
verzi, na kterou aktualizuješ — najdeš ji podle čísla verze níž.

---

## 📋 Obecný postup aktualizace (přes HACS)

1. **HACS → Integrace → AI Asistent (Ollama) → Aktualizovat / Update**
2. Po dokončení stahování **restartuj Home Assistant**
   (Nastavení → Systém → Restartovat).
3. Zkontroluj log (**Nastavení → Systém → Protokoly**) — hledej `ollama_assistant`,
   ať vidíš, že se integrace načetla bez chyb.
4. Pokud verze obsahuje ⚠️ **ROZBÍJEJÍCÍ ZMĚNU**, projdi si příslušnou sekci
   níže *před* restartem.
5. Zkontroluj **Nastavení → Zařízení a služby → AI Asistent (Ollama) →
   Možnosti**, jestli tvoje dosavadní nastavení (jazyk, prompt, API) zůstalo
   zachováno — options flow je navržen tak, aby se zachovávalo automaticky,
   ale u větších verzí to stojí za kontrolu.

> 💡 **Tip:** Před každou aktualizací si v HACS můžeš stáhnout zálohu
> (Home Assistant → Nastavení → Systém → Zálohy), pokud chceš mít jistotu.

---

## Jak číst tuto stránku

Každá verze má:
- **Co je nového** — stručně, odkaz na plný [CHANGELOG.md](CHANGELOG.md)
- **Vyžaduje zásah?** — Ano/Ne
- **Kroky navíc** — pokud vyžaduje zásah, přesný postup

---

## [2.0.0] — 2024-07-25

**Co je nového:** Velký update — rozpoznávání obličejů + automatické odemykání dveří!
Viz [CHANGELOG.md](CHANGELOG.md#200---2024-07-25) pro plný seznam.

**Vyžaduje zásah?** ⚠️ **ANO** — jsou tu nová nastavení v config flow.

### Postup aktualizace

1. **HACS → Integrace → Aktualizovat** integraci na verzi 2.0.0
2. **Restart Home Assistant** (Nastavení → Systém → Restartovat)
3. **Proveď nová nastavení** (viz níže)

### Nová nastavení v Možnostech

Po upgradu otevři **Nastavení → Zařízení a služby → AI Asistent (Ollama) → Možnosti (Configure)**
a zde nastaví nové volby:

#### 🎥 Face Recognition (Rozpoznávání obličejů)

- [ ] **Zapni Face Recognition** — zaškrtni, pokud chceš detekovat obličeje z kamer
- [ ] **Vyber kamery** — které kamery mají sledovat obličeje (víc možností najednou)
- [ ] **Práh jistoty** — na kolik procent musí být jistota (doporučuji 0.7–0.8)

> 💡 **Tip:** Pokud nemáš kamery, zatím to nech vypnuto. Face Recognition bude v budoucí verzi
> kompletně implementován — zatím je core struktura připravená.

#### 🔐 Lock Control (Odemykání dveří)

- [ ] **Vyber zámky** — které zámky mají být dostupné pro automatické odemykání

Jakmile vytvořiš alespoň jednu kameru a jeden zámek, můžeš si nastavit pravidla přístupu
(access rules) — podrobnosti v [LOCK_CONTROL_GUIDE.md](LOCK_CONTROL_GUIDE.md).

### Příklady nových automatizací

Podívej se do `example_config.yaml` — sekce „Face Recognition Examples" (nová).

### Pokud něco nefunguje

- Zaškrtni všechna nová nastavení, ale nech Face Recognition **vypnuto** (pokud nemáš
  implementovánu detekci obličejů). Integrace bude fungovat jako předtím, jen s novými
  moduly na pozadí.
- Zkontroluj log (**Nastavení → Systém → Protokoly**, hledej `ollama_assistant`), jestli
  nejsou chyby při importu nových modulů.

---

## [1.0.0] — 2024-07-24

**Co je nového:** První vydání. Není z čeho upgradovat. 🎉

**Vyžaduje zásah?** Ne — jde o čistou instalaci.

**Kroky navíc:** Postupuj podle [README.md](README.md), sekce „Nastavení integrace“.

---

## 🆘 Co dělat, když aktualizace nedopadne dobře

| Příznak | Řešení |
|---------|--------|
| Integrace se po restartu nenačte, log hlásí `ImportError` nebo podobné | HACS → Redownload / Znovu stáhnout, pak restart HA |
| Chyba u `llm.async_get_api` / `llm.APIInstance` v logu | Interní API Home Assistant se změnilo — zkontroluj [README.md](README.md#poznámka-k-verzím-home-assistant) a otevři [Issue](https://github.com/USER/ollama-ha-assistant/issues) |
| Nastavení (jazyk, prompt) po update zmizelo | Znovu otevři Možnosti / Configure integrace a nastav znovu — ulož Issue, ať to opravíme |
| Ollama server přestal odpovídat po update | Zkontroluj, že Ollama běží (`ollama list` na serveru) — nesouvisí s update integrace |

Pokud problém přetrvává, otevři [GitHub Issue](https://github.com/USER/ollama-ha-assistant/issues/new/choose)
s výstupem z logu a číslem verze, ze které a na kterou jsi aktualizoval.

---

## 🔔 Jak se dozvíš o nové verzi

- **HACS** tě upozorní v postranním panelu, jakmile je dostupná nová verze.
- Pokud máš zapnuté [Repository notifications na GitHubu](https://docs.github.com/en/account-and-profile/managing-subscriptions-and-notifications-on-github/setting-up-notifications/configuring-notifications#configuring-your-watch-settings-for-an-individual-repository)
  pro tento repozitář (Watch → Custom → Releases), přijde ti i e-mail/notifikace.
- Doporučujeme si navíc nastavit automatizaci v Home Assistant, která tě
  upozorní přímo v aplikaci — šablona je v [`example_config.yaml`](example_config.yaml)
  (sekce „Upozornění na novou verzi integrace“).

---

*Tento soubor se aktualizuje s každým vydáním — viz [CHANGELOG.md](CHANGELOG.md) pro plný technický výčet změn.*
