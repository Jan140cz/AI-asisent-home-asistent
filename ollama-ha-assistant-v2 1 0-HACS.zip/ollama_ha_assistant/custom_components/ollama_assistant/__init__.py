"""Integrace AI Asistent (Ollama) pro Home Assistant."""

from __future__ import annotations

import logging

import voluptuous as vol

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.helpers import config_validation as cv

from .const import CONF_TTS_ENTITY, CONF_TTS_VOICE, DOMAIN

_LOGGER = logging.getLogger(__name__)

PLATFORMS = ["conversation"]

SERVICE_SPEAK = "speak"
SERVICE_SPEAK_SCHEMA = vol.Schema(
    {
        vol.Required("message"): cv.string,
        vol.Required("media_player_entity_id"): cv.entity_id,
    }
)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Nastaví integraci ze záznamu konfigurace (config entry)."""
    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN][entry.entry_id] = entry

    try:
        await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    except Exception as err:  # noqa: BLE001 - selhání nastavení nesmí spadnout celý HA
        _LOGGER.error("Nepodařilo se nastavit AI Asistenta: %s", err)
        return False

    entry.async_on_unload(entry.add_update_listener(async_update_options))
    _async_register_services(hass)
    return True


def _async_register_services(hass: HomeAssistant) -> None:
    """Zaregistruje službu 'ollama_assistant.speak' (jen jednou, bez ohledu na počet entries)."""
    if hass.services.has_service(DOMAIN, SERVICE_SPEAK):
        return

    async def _handle_speak(call: ServiceCall) -> None:
        # Vezmeme nastavení hlasu z první nakonfigurované instance integrace.
        entries = list(hass.data.get(DOMAIN, {}).values())
        tts_entity = "none"
        tts_voice = ""
        for entry in entries:
            if not isinstance(entry, ConfigEntry):
                continue
            tts_entity = entry.options.get(CONF_TTS_ENTITY, "none")
            tts_voice = entry.options.get(CONF_TTS_VOICE, "")
            if tts_entity and tts_entity != "none":
                break

        if not tts_entity or tts_entity == "none":
            _LOGGER.warning(
                "Není vybraný žádný hlas (TTS) v Možnostech AI Asistenta - "
                "použije se výchozí hlas Home Assistant."
            )
            tts_entity = None

        service_data: dict = {
            "entity_id": tts_entity,
            "media_player_entity_id": call.data["media_player_entity_id"],
            "message": call.data["message"],
        }
        if tts_voice:
            service_data["options"] = {"voice": tts_voice}
        if tts_entity is None:
            service_data.pop("entity_id")

        await hass.services.async_call(
            "tts", "speak", service_data, blocking=True
        )

    hass.services.async_register(
        DOMAIN, SERVICE_SPEAK, _handle_speak, schema=SERVICE_SPEAK_SCHEMA
    )


async def async_update_options(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Znovu načte integraci po změně nastavení (např. změna jazyka)."""
    await hass.config_entries.async_reload(entry.entry_id)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Odebere integraci."""
    unloaded = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unloaded:
        hass.data.get(DOMAIN, {}).pop(entry.entry_id, None)
        if not hass.data.get(DOMAIN):
            hass.services.async_remove(DOMAIN, SERVICE_SPEAK)
    return unloaded
