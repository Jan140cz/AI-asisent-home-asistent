"""Config flow pro AI Asistenta (Ollama)."""

from __future__ import annotations

import logging
from typing import Any

import ollama
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.const import CONF_HOST
from homeassistant.core import HomeAssistant
from homeassistant.core import callback
from homeassistant.helpers import llm
from homeassistant.helpers.selector import (
    BooleanSelector,
    NumberSelector,
    NumberSelectorConfig,
    NumberSelectorMode,
    SelectSelector,
    SelectSelectorConfig,
    SelectSelectorMode,
    TemplateSelector,
    TextSelector,
    TextSelectorConfig,
    EntityMultiSelector,
    EntityMultiSelectorConfig,
    EntitySelector,
    EntitySelectorConfig,
)

from .const import (
    CONF_ACCESS_RULES,
    CONF_FACE_RECOGNITION_CAMERAS,
    CONF_FACE_RECOGNITION_CONFIDENCE,
    CONF_FACE_RECOGNITION_ENABLED,
    CONF_LANGUAGE,
    CONF_LLM_HASS_API,
    CONF_LOCK_ENTITIES,
    CONF_MODEL,
    CONF_PROMPT,
    CONF_TELEGRAM_ENABLED,
    CONF_TELEGRAM_NOTIFY_SERVICE,
    CONF_TEMPERATURE,
    CONF_TTS_ENTITY,
    CONF_TTS_VOICE,
    DEFAULT_FACE_RECOGNITION_CONFIDENCE,
    DEFAULT_FACE_RECOGNITION_ENABLED,
    DEFAULT_LANGUAGE,
    DEFAULT_MODEL,
    DEFAULT_PROMPT,
    DEFAULT_TELEGRAM_ENABLED,
    DEFAULT_TELEGRAM_NOTIFY_SERVICE,
    DEFAULT_TEMPERATURE,
    DEFAULT_TTS_VOICE,
    DOMAIN,
    LANGUAGE_OPTIONS,
)

_LOGGER = logging.getLogger(__name__)


async def _validate_connection(host: str) -> tuple[bool, list[str], str]:
    """Ověří, že je Ollama server dostupný a vrátí seznam modelů.

    Vrátí (success, models, error_code) tuple.
    - success: True pokud se připojit povedlo
    - models: seznam dostupných modelů (prázdný seznam pokud se nenačetl)
    - error_code: "cannot_connect" nebo "no_models"
    """
    try:
        client = ollama.AsyncClient(host=host)
        response = await client.list()
        models = [m.get("name", "unknown") for m in response.get("models", [])]
        if not models:
            return False, [], "no_models"
        return True, models, ""
    except Exception as err:  # noqa: BLE001
        _LOGGER.warning("Připojení k Ollama (%s) selhalo: %s", host, err)
        return False, [], "cannot_connect"


class OllamaAssistantConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Průvodce prvotním nastavením integrace."""

    VERSION = 1

    def __init__(self) -> None:
        self._host: str = ""
        self._models: list[str] = []

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> config_entries.ConfigFlowResult:
        """Krok 1: Zadání adresy Ollama serveru."""
        errors: dict[str, str] = {}

        if user_input is not None:
            self._host = user_input[CONF_HOST].rstrip("/")
            success, models, error_code = await _validate_connection(self._host)

            if not success:
                errors["base"] = error_code
            else:
                self._models = models
                return await self.async_step_model()

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Required(
                        CONF_HOST, default="http://homeassistant.local:11434"
                    ): str,
                }
            ),
            errors=errors,
        )

    async def async_step_model(
        self, user_input: dict[str, Any] | None = None
    ) -> config_entries.ConfigFlowResult:
        """Krok 2: Výběr modelu ze seznamu dostupných na serveru."""
        if user_input is not None:
            model = user_input[CONF_MODEL]
            await self.async_set_unique_id(f"{self._host}::{model}")
            self._abort_if_unique_id_configured()
            return self.async_create_entry(
                title=f"AI Asistent ({model})",
                data={CONF_HOST: self._host, CONF_MODEL: model},
            )

        # Prepare model options
        model_options = [
            {"value": m, "label": m} for m in self._models
        ] if self._models else []

        if not model_options:
            # Fallback: pokud se modely nenačetly, umožni ruční zadání
            model_options = [
                {"value": "llama3.1", "label": "llama3.1"},
                {"value": "mistral-nemo", "label": "mistral-nemo"},
                {"value": "qwen2.5", "label": "qwen2.5"},
            ]

        return self.async_show_form(
            step_id="model",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_MODEL, default=self._models[0] if self._models else "llama3.1"): SelectSelector(
                        SelectSelectorConfig(
                            options=model_options, mode=SelectSelectorMode.DROPDOWN
                        )
                    ),
                }
            ),
        )

    @staticmethod
    @callback
    def async_get_options_flow(
        config_entry: config_entries.ConfigEntry,
    ) -> OllamaAssistantOptionsFlow:
        return OllamaAssistantOptionsFlow(config_entry)


class OllamaAssistantOptionsFlow(config_entries.OptionsFlow):
    """Nastavení chování asistenta - jazyk, osobnost, ovládání zařízení."""

    def __init__(self, config_entry: config_entries.ConfigEntry) -> None:
        self.config_entry = config_entry

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> config_entries.ConfigFlowResult:
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        hass: HomeAssistant = self.hass

        api_options = [{"value": "none", "label": "Žádné (pouze konverzace, bez ovládání)"}]
        try:
            api_options += [
                {"value": api.id, "label": api.name} for api in llm.async_get_apis(hass)
            ]
        except Exception as err:  # noqa: BLE001
            _LOGGER.debug("Nelze načíst seznam LLM API: %s", err)

        options = self.config_entry.options

        # Nabídneme jenom TTS entity, které si uživatel v HA už nastavil
        # (Nastavení → Hlasoví asistenti → Text na řeč).
        tts_entity_options = [{"value": "none", "label": "Beze změny hlasu (výchozí)"}]
        for state in hass.states.async_all("tts"):
            tts_entity_options.append(
                {"value": state.entity_id, "label": state.name or state.entity_id}
            )

        schema = vol.Schema(
            {
                vol.Optional(
                    CONF_PROMPT,
                    default=options.get(CONF_PROMPT, DEFAULT_PROMPT),
                ): TemplateSelector(),
                vol.Optional(
                    CONF_LANGUAGE,
                    default=options.get(CONF_LANGUAGE, DEFAULT_LANGUAGE),
                ): SelectSelector(
                    SelectSelectorConfig(
                        options=LANGUAGE_OPTIONS, mode=SelectSelectorMode.DROPDOWN
                    )
                ),
                vol.Optional(
                    CONF_TEMPERATURE,
                    default=options.get(CONF_TEMPERATURE, DEFAULT_TEMPERATURE),
                ): NumberSelector(
                    NumberSelectorConfig(min=0, max=2, step=0.1, mode=NumberSelectorMode.SLIDER)
                ),
                vol.Optional(
                    CONF_LLM_HASS_API,
                    default=options.get(CONF_LLM_HASS_API, "none"),
                ): SelectSelector(
                    SelectSelectorConfig(options=api_options, mode=SelectSelectorMode.DROPDOWN)
                ),
                vol.Optional(
                    CONF_FACE_RECOGNITION_ENABLED,
                    default=options.get(CONF_FACE_RECOGNITION_ENABLED, DEFAULT_FACE_RECOGNITION_ENABLED),
                ): BooleanSelector(),
                vol.Optional(
                    CONF_FACE_RECOGNITION_CAMERAS,
                    default=options.get(CONF_FACE_RECOGNITION_CAMERAS, []),
                ): EntityMultiSelector(
                    EntityMultiSelectorConfig(domain="camera")
                ),
                vol.Optional(
                    CONF_FACE_RECOGNITION_CONFIDENCE,
                    default=options.get(CONF_FACE_RECOGNITION_CONFIDENCE, DEFAULT_FACE_RECOGNITION_CONFIDENCE),
                ): NumberSelector(
                    NumberSelectorConfig(min=0, max=1, step=0.05, mode=NumberSelectorMode.SLIDER)
                ),
                vol.Optional(
                    CONF_LOCK_ENTITIES,
                    default=options.get(CONF_LOCK_ENTITIES, []),
                ): EntityMultiSelector(
                    EntityMultiSelectorConfig(domain="lock")
                ),
                vol.Optional(
                    CONF_TTS_ENTITY,
                    default=options.get(CONF_TTS_ENTITY, "none"),
                ): SelectSelector(
                    SelectSelectorConfig(
                        options=tts_entity_options, mode=SelectSelectorMode.DROPDOWN
                    )
                ),
                vol.Optional(
                    CONF_TTS_VOICE,
                    default=options.get(CONF_TTS_VOICE, DEFAULT_TTS_VOICE),
                ): TextSelector(TextSelectorConfig()),
                vol.Optional(
                    CONF_TELEGRAM_ENABLED,
                    default=options.get(CONF_TELEGRAM_ENABLED, DEFAULT_TELEGRAM_ENABLED),
                ): BooleanSelector(),
                vol.Optional(
                    CONF_TELEGRAM_NOTIFY_SERVICE,
                    default=options.get(
                        CONF_TELEGRAM_NOTIFY_SERVICE, DEFAULT_TELEGRAM_NOTIFY_SERVICE
                    ),
                ): TextSelector(TextSelectorConfig()),
            }
        )
        return self.async_show_form(step_id="init", data_schema=schema)
