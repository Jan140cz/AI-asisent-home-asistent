"""Konstanty pro integraci AI Asistent (Ollama)."""

DOMAIN = "ollama_assistant"

CONF_MODEL = "model"
CONF_LANGUAGE = "language"
CONF_PROMPT = "prompt"
CONF_TEMPERATURE = "temperature"
CONF_LLM_HASS_API = "llm_hass_api"

# Face Recognition
CONF_FACE_RECOGNITION_ENABLED = "face_recognition_enabled"
CONF_FACE_RECOGNITION_CAMERAS = "face_recognition_cameras"
CONF_FACE_RECOGNITION_CONFIDENCE = "face_recognition_confidence"
CONF_LOCK_ENTITIES = "lock_entities"
CONF_ACCESS_RULES = "access_rules"

# Hlas asistenta (TTS)
CONF_TTS_ENTITY = "tts_entity"
CONF_TTS_VOICE = "tts_voice"

# Telegram notifikace
CONF_TELEGRAM_ENABLED = "telegram_enabled"
CONF_TELEGRAM_NOTIFY_SERVICE = "telegram_notify_service"

DEFAULT_MODEL = "llama3.1"
DEFAULT_TEMPERATURE = 0.7
DEFAULT_FACE_RECOGNITION_ENABLED = False
DEFAULT_FACE_RECOGNITION_CONFIDENCE = 0.7
DEFAULT_TTS_VOICE = ""
DEFAULT_TELEGRAM_ENABLED = False
DEFAULT_TELEGRAM_NOTIFY_SERVICE = "telegram"

# Kolikrát maximálně smí model po sobě volat nástroje v jedné odpovědi,
# než se smyčka násilně ukončí. Chrání to proti nekonečné smyčce / pádu.
MAX_TOOL_ITERATIONS = 5

DEFAULT_PROMPT = (
    "Jsi užitečný hlasový asistent integrovaný do systému Home Assistant. "
    "Odpovídej stručně, věcně a přátelsky. Pokud si nejsi jistý, raději se zeptej, "
    "než abys něco pokazil."
)

DEFAULT_LANGUAGE = "cs"

# Jazyky, ve kterých má asistent umět odpovídat. Uživatel si v nastavení
# integrace vybere jeden z nich jako výchozí jazyk odpovědí.
LANGUAGE_NAMES = {
    "cs": "Čeština",
    "sk": "Slovenština",
    "en": "Angličtina",
    "de": "Němčina",
    "pl": "Polština",
    "uk": "Ukrajinština",
    "es": "Španělština",
    "fr": "Francouzština",
}

LANGUAGE_OPTIONS = [
    {"value": code, "label": name} for code, name in LANGUAGE_NAMES.items()
]
