"""Konverzační agent, který odpovídá pomocí lokálního modelu Ollama."""

from __future__ import annotations

import json
import logging
from typing import Any, Literal

import ollama

try:
    from voluptuous_openapi import convert
except ImportError:  # pragma: no cover - ochrana proti chybějící závislosti
    convert = None

from homeassistant.components import conversation
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_HOST, MATCH_ALL
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers import intent, llm
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.util import ulid as ulid_util

from .const import (
    CONF_LANGUAGE,
    CONF_LLM_HASS_API,
    CONF_MODEL,
    CONF_PROMPT,
    CONF_TELEGRAM_ENABLED,
    CONF_TELEGRAM_NOTIFY_SERVICE,
    CONF_TEMPERATURE,
    DEFAULT_LANGUAGE,
    DEFAULT_MODEL,
    DEFAULT_PROMPT,
    DEFAULT_TELEGRAM_ENABLED,
    DEFAULT_TELEGRAM_NOTIFY_SERVICE,
    DEFAULT_TEMPERATURE,
    DOMAIN,
    LANGUAGE_NAMES,
    MAX_TOOL_ITERATIONS,
)

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Vytvoří entitu konverzačního agenta."""
    async_add_entities([OllamaAssistantEntity(hass, entry)])


def _format_tool(tool: llm.Tool, custom_serializer: Any) -> dict[str, Any]:
    """Převede nástroj (službu) Home Assistant do formátu, kterému rozumí Ollama."""
    parameters = (
        convert(tool.parameters, custom_serializer=custom_serializer)
        if convert is not None
        else {"type": "object", "properties": {}}
    )
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description or "",
            "parameters": parameters,
        },
    }


class OllamaAssistantEntity(
    conversation.ConversationEntity, conversation.AbstractConversationAgent
):
    """Konverzační agent poháněný lokálním modelem přes Ollama."""

    _attr_has_entity_name = True
    _attr_name = "AI Asistent"

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        self.hass = hass
        self.entry = entry
        self._attr_unique_id = entry.entry_id
        # Historie konverzací podle conversation_id, aby si asistent
        # pamatoval kontext v rámci jednoho rozhovoru.
        self._history: dict[str, list[dict[str, Any]]] = {}

    @property
    def supported_languages(self) -> list[str] | Literal["*"]:
        # Jazyk odpovědí řešíme sami v system promptu, takže agent
        # přijímá vstup v libovolném jazyce.
        return MATCH_ALL

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        conversation.async_set_agent(self.hass, self.entry, self)

    async def async_will_remove_from_hass(self) -> None:
        conversation.async_unset_agent(self.hass, self.entry)
        await super().async_will_remove_from_hass()

    @staticmethod
    def _language_name(code: str) -> str:
        return LANGUAGE_NAMES.get(code, code)

    def _build_system_prompt(self, language: str, llm_api: llm.APIInstance | None) -> str:
        options = self.entry.options
        base_prompt = options.get(CONF_PROMPT, DEFAULT_PROMPT)

        prompt = (
            f"{base_prompt}\n\n"
            f"Vždy odpovídej v jazyce: {self._language_name(language)}, "
            "bez ohledu na to, v jakém jazyce je otázka napsaná, pokud uživatel "
            "výslovně nepožádá o jiný jazyk.\n"
            "Pokud uživatel žádá o ovládání zařízení nebo splnění úkolu v domácnosti "
            "a máš k dispozici odpovídající nástroj, použij ho. Pokud nástroj selže "
            "nebo požadovaná akce není možná, jasně a stručně to uživateli vysvětli - "
            "nikdy si nevymýšlej, že se něco stalo, když se to nestalo."
        )
        if llm_api is not None:
            prompt += "\n\n" + llm_api.api_prompt
        return prompt

    async def _get_llm_api(
        self, user_input: conversation.ConversationInput, language: str
    ) -> llm.APIInstance | None:
        llm_api_id = self.entry.options.get(CONF_LLM_HASS_API, "none")
        if not llm_api_id or llm_api_id == "none":
            return None
        try:
            return await llm.async_get_api(
                self.hass,
                llm_api_id,
                llm.LLMContext(
                    platform=DOMAIN,
                    context=user_input.context,
                    language=language,
                    assistant=conversation.DOMAIN,
                    device_id=user_input.device_id,
                ),
            )
        except HomeAssistantError as err:
            _LOGGER.warning("Nelze načíst nástroje pro ovládání Home Assistant: %s", err)
            return None

    async def async_process(
        self, user_input: conversation.ConversationInput
    ) -> conversation.ConversationResult:
        options = self.entry.options
        language = user_input.language or options.get(CONF_LANGUAGE, DEFAULT_LANGUAGE)
        model = self.entry.data.get(CONF_MODEL, DEFAULT_MODEL)
        host = self.entry.data.get(CONF_HOST)
        temperature = options.get(CONF_TEMPERATURE, DEFAULT_TEMPERATURE)

        conversation_id = user_input.conversation_id or ulid_util.ulid_now()
        messages = self._history.get(conversation_id)

        llm_api = await self._get_llm_api(user_input, language)
        tools: list[dict[str, Any]] | None = None
        if llm_api is not None:
            tools = [_format_tool(t, llm_api.custom_serializer) for t in llm_api.tools]

        if messages is None:
            messages = [
                {
                    "role": "system",
                    "content": self._build_system_prompt(language, llm_api),
                }
            ]

        messages.append({"role": "user", "content": user_input.text})

        client = ollama.AsyncClient(host=host)

        try:
            for iteration in range(MAX_TOOL_ITERATIONS):
                response = await client.chat(
                    model=model,
                    messages=messages,
                    tools=tools or None,
                    options={"temperature": temperature},
                )
                message = dict(response["message"])
                messages.append(message)

                tool_calls = message.get("tool_calls")
                if not tool_calls or llm_api is None:
                    break

                for tool_call in tool_calls:
                    function = tool_call["function"]
                    tool_name = function["name"]
                    tool_args = function.get("arguments") or {}
                    try:
                        result = await llm_api.async_call_tool(
                            llm.ToolInput(tool_name=tool_name, tool_args=tool_args)
                        )
                    except HomeAssistantError as err:
                        _LOGGER.warning("Nástroj '%s' selhal: %s", tool_name, err)
                        result = {"error": str(err)}
                    messages.append(
                        {"role": "tool", "content": json.dumps(result, default=str)}
                    )
            else:
                _LOGGER.warning(
                    "Dosažen limit %s volání nástrojů za sebou - odpověď se ukončuje, "
                    "aby se předešlo nekonečné smyčce.",
                    MAX_TOOL_ITERATIONS,
                )

        except (ollama.ResponseError, ConnectionError, TimeoutError) as err:
            _LOGGER.error("Chyba komunikace s Ollama serverem (%s): %s", host, err)
            return self._error_result(
                user_input,
                conversation_id,
                language,
                "Nemohu se připojit k lokálnímu AI serveru Ollama. Zkontroluj prosím, "
                "že běží a že je adresa v nastavení integrace správná.",
            )
        except Exception as err:  # noqa: BLE001 - asistent nesmí nikdy shodit Home Assistant
            _LOGGER.exception("Neočekávaná chyba AI asistenta: %s", err)
            return self._error_result(
                user_input,
                conversation_id,
                language,
                "Došlo k neočekávané chybě při zpracování požadavku. "
                "Zkus to prosím znovu nebo zkontroluj log Home Assistant.",
            )

        self._history[conversation_id] = messages
        reply_text = messages[-1].get("content") or (
            "Omlouvám se, nepodařilo se mi vygenerovat odpověď."
        )

        await self._send_telegram_notification(reply_text)

        intent_response = intent.IntentResponse(language=language)
        intent_response.async_set_speech(reply_text)
        return conversation.ConversationResult(
            response=intent_response, conversation_id=conversation_id
        )

    async def _send_telegram_notification(self, text: str) -> None:
        """Pošle odpověď asistenta i na Telegram, pokud je to zapnuté v Možnostech.

        Vyžaduje, aby uživatel měl v Home Assistant nastavenou integraci
        "Telegram bot" (Nastavení → Zařízení a služby → Přidat integraci →
        Telegram bot) - viz TELEGRAM_GUIDE.md. Selhání odeslání nikdy
        nezpůsobí chybu konverzace, jen se zaloguje.
        """
        options = self.entry.options
        if not options.get(CONF_TELEGRAM_ENABLED, DEFAULT_TELEGRAM_ENABLED):
            return

        service = options.get(
            CONF_TELEGRAM_NOTIFY_SERVICE, DEFAULT_TELEGRAM_NOTIFY_SERVICE
        ).strip()
        if not service:
            return

        try:
            await self.hass.services.async_call(
                "notify",
                service,
                {"message": text},
                blocking=False,
            )
        except Exception as err:  # noqa: BLE001 - odeslání na Telegram nesmí shodit konverzaci
            _LOGGER.warning(
                "Nepodařilo se odeslat odpověď na Telegram (notify.%s): %s. "
                "Zkontroluj, že integrace Telegram bot je nastavená a název "
                "notifikační služby v Možnostech AI Asistenta odpovídá "
                "(viz TELEGRAM_GUIDE.md).",
                service,
                err,
            )

    @staticmethod
    def _error_result(
        user_input: conversation.ConversationInput,
        conversation_id: str,
        language: str,
        message: str,
    ) -> conversation.ConversationResult:
        intent_response = intent.IntentResponse(language=language)
        intent_response.async_set_error(intent.IntentResponseErrorCode.UNKNOWN, message)
        return conversation.ConversationResult(
            response=intent_response, conversation_id=conversation_id
        )
