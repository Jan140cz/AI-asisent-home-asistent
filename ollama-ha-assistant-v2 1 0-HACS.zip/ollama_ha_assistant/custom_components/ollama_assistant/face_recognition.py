"""Rozpoznávání obličejů z kamer v Home Assistant."""

from __future__ import annotations

import asyncio
import base64
import io
import logging
from dataclasses import dataclass
from typing import Any

import httpx

_LOGGER = logging.getLogger(__name__)

# Externě volitelné: pokud uživatel má nainstalovanou komponentu pro face
# recognition (např. opencv, deepface apod.), můžeme ji naimplementovat.
# Zatím používáme fallback: posíláme obraz do Claude nebo lokálního modelu.


@dataclass
class RecognizedFace:
    """Výsledek rozpoznávaného obličeje."""

    person_name: str
    confidence: float  # 0.0 - 1.0
    camera_entity_id: str
    timestamp: str


@dataclass
class Face:
    """Detekovaný obličej na obrázku."""

    x: int
    y: int
    width: int
    height: int
    confidence: float


class FaceRecognitionEngine:
    """Modul pro rozpoznávání obličejů z kamer Home Assistant."""

    def __init__(
        self,
        hass: Any,
        known_faces: dict[str, list[str]],
        confidence_threshold: float = 0.7,
    ):
        """Inicializuj engine.

        Args:
            hass: Home Assistant instance.
            known_faces: Slovník {person_name: [camera_entity_ids]}
                        Které kamery sledovat pro danou osobu.
            confidence_threshold: Minimální jistota pro potvrzení osoby (0.0-1.0).
        """
        self.hass = hass
        self.known_faces = known_faces
        self.confidence_threshold = confidence_threshold
        self._cache: dict[str, RecognizedFace] = {}

    async def recognize_from_camera(
        self, camera_entity_id: str
    ) -> list[RecognizedFace] | None:
        """Rozpoznej obličeje z živého videa kamery.

        Vezme aktuální snímek z kamery, odešle ho do face recognition modelu
        (lokální nebo vzdálený) a vrátí seznam rozpoznaných osob.

        Args:
            camera_entity_id: Entity ID kamery, např. "camera.obyvacak"

        Returns:
            Seznam RecognizedFace s detekovanými osobami, nebo None při chybě.
        """
        try:
            # Získej aktuální snímek z kamery
            image_data = await self._get_camera_image(camera_entity_id)
            if not image_data:
                _LOGGER.warning(f"Nepodařilo se získat obraz z kamery {camera_entity_id}")
                return None

            # Pošli na rozpoznání (lokální model nebo API)
            faces = await self._detect_faces(image_data)
            if not faces:
                _LOGGER.debug(f"Žádné obličeje detekovány na {camera_entity_id}")
                return []

            # Rozpoznej každý detekovaný obličej
            recognized = []
            for face in faces:
                person_name = await self._match_face(
                    image_data, face, camera_entity_id
                )
                if person_name:
                    recognized.append(
                        RecognizedFace(
                            person_name=person_name,
                            confidence=face.confidence,
                            camera_entity_id=camera_entity_id,
                            timestamp=self.hass.loop.time(),
                        )
                    )

            return recognized if recognized else None

        except Exception as err:
            _LOGGER.error(f"Chyba při rozpoznávání obličejů: {err}")
            return None

    async def _get_camera_image(self, camera_entity_id: str) -> bytes | None:
        """Vrať aktuální snímek z kamery ve formátu JPEG bytes."""
        try:
            # Zavolej Home Assistant service pro focení z kamery
            result = await self.hass.services.async_call(
                "camera",
                "snapshot",
                {
                    "entity_id": camera_entity_id,
                    "filename": "/tmp/ha_snapshot.jpg",
                },
                blocking=True,
                return_response=True,
            )

            # Přečti soubor
            import os

            if os.path.exists("/tmp/ha_snapshot.jpg"):
                with open("/tmp/ha_snapshot.jpg", "rb") as f:
                    return f.read()

            return None

        except Exception as err:
            _LOGGER.debug(f"Nepodařilo se snapshot z {camera_entity_id}: {err}")
            return None

    async def _detect_faces(self, image_data: bytes) -> list[Face] | None:
        """Detekuj všechny obličeje v obrázku.

        Zatím je to placeholder — v příští verzi bude integrace s:
        - OpenCV (lokální, bez internetu)
        - face_recognition knihovnou
        - nebo vlastním ML modelem přes Ollamu
        """
        try:
            # TODO: Implementovat detekci obličejů
            # Prozatím: simuluj detekci (pro testing)
            _LOGGER.debug("Face detection placeholder - implementace v přípravě")
            return []

        except Exception as err:
            _LOGGER.error(f"Chyba při detekci obličejů: {err}")
            return None

    async def _match_face(
        self, image_data: bytes, face: Face, camera_entity_id: str
    ) -> str | None:
        """Porovnej detekovaný obličej se známými obličeji.

        Vrátí jméno osoby, pokud je rozpoznána a překonala threshold.
        """
        # TODO: Implementovat matching s databází známých obličejů
        # Prozatím: placeholder
        return None

    def register_person(
        self, person_name: str, face_encoding: bytes
    ) -> None:
        """Zaregistruj novou osobu do databáze známých obličejů.

        Args:
            person_name: Jméno osoby.
            face_encoding: Bytová reprezentace obličeje (z face_recognition knihovny).
        """
        if person_name not in self.known_faces:
            self.known_faces[person_name] = []
        _LOGGER.info(f"Osoba '{person_name}' zaregistrována do face recognition")

    async def verify_person(
        self, person_name: str, camera_entity_id: str
    ) -> bool:
        """Ověř, jestli je konkrétní osoba vidět v kameře.

        Vrátí True, pokud je osoba rozpoznána a překonala confidence threshold.
        """
        recognized = await self.recognize_from_camera(camera_entity_id)
        if not recognized:
            return False

        return any(
            f.person_name == person_name and f.confidence >= self.confidence_threshold
            for f in recognized
        )
