"""Ovládání zámků a akcí na základě rozpoznávaného obličeje."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable

_LOGGER = logging.getLogger(__name__)


class ActionType(Enum):
    """Typ akce, která se spustí při rozpoznání obličeje."""

    UNLOCK_DOOR = "unlock"  # Odemkni dveře
    LOCK_DOOR = "lock"  # Zamkni dveře
    TURN_ON_LIGHT = "turn_on_light"  # Rozsvítí světlo
    TURN_OFF_LIGHT = "turn_off_light"  # Zhasne světlo
    OPEN_GARAGE = "open_garage"  # Otevře garáž
    SEND_NOTIFICATION = "notification"  # Pošle notifikaci
    CUSTOM_SCENE = "scene"  # Spustí scénu (např. "Příchod domů")
    CALL_SERVICE = "service_call"  # Zavolá libovolnou HA službu


@dataclass
class AccessRule:
    """Pravidlo přístupu: co se stane, když je určitá osoba rozpoznána."""

    person_name: str
    action_type: ActionType
    target_entity_id: str  # Entita, kterou ovládat (zámek, světlo, apod.)
    enabled: bool = True
    conditions: dict[str, Any] | None = None  # Dodatečné podmínky (čas, stav, apod.)
    metadata: dict[str, Any] | None = None  # Další data pro akci


class LockControlEngine:
    """Modul pro ovládání zámků a automatických akcí na základě rozpoznání obličejů."""

    def __init__(self, hass: Any):
        """Inicializuj engine.

        Args:
            hass: Home Assistant instance.
        """
        self.hass = hass
        self.access_rules: list[AccessRule] = []
        self._action_callbacks: dict[ActionType, Callable] = {
            ActionType.UNLOCK_DOOR: self._action_unlock_door,
            ActionType.LOCK_DOOR: self._action_lock_door,
            ActionType.TURN_ON_LIGHT: self._action_turn_on_light,
            ActionType.TURN_OFF_LIGHT: self._action_turn_off_light,
            ActionType.OPEN_GARAGE: self._action_open_garage,
            ActionType.SEND_NOTIFICATION: self._action_send_notification,
            ActionType.CUSTOM_SCENE: self._action_activate_scene,
            ActionType.CALL_SERVICE: self._action_call_service,
        }

    def add_access_rule(self, rule: AccessRule) -> None:
        """Přidej nové pravidlo přístupu."""
        self.access_rules.append(rule)
        _LOGGER.info(
            f"Pravidlo přístupu přidáno: {rule.person_name} → {rule.action_type.value}"
        )

    def remove_access_rule(self, person_name: str, action_type: ActionType) -> None:
        """Odeber pravidlo přístupu."""
        self.access_rules = [
            r
            for r in self.access_rules
            if not (r.person_name == person_name and r.action_type == action_type)
        ]

    def get_rules_for_person(self, person_name: str) -> list[AccessRule]:
        """Vrať všechna pravidla pro určitou osobu."""
        return [r for r in self.access_rules if r.person_name == person_name and r.enabled]

    async def execute_person_actions(self, person_name: str) -> list[str]:
        """Spusť všechny akce přiřazené k rozpoznané osobě.

        Vrátí seznam zpráv o tom, co se stalo.
        """
        rules = self.get_rules_for_person(person_name)
        if not rules:
            return [f"Žádné akce přiřazeny k osobě '{person_name}'"]

        results = []
        for rule in rules:
            # Zkontroluj dodatečné podmínky (pokud jsou)
            if rule.conditions and not await self._check_conditions(rule.conditions):
                _LOGGER.debug(f"Pravidlo {rule} nevyhovovalo podmínkám")
                continue

            # Spusť akci
            try:
                action_fn = self._action_callbacks.get(rule.action_type)
                if action_fn:
                    result = await action_fn(rule)
                    results.append(result)
                else:
                    _LOGGER.warning(f"Neznámý typ akce: {rule.action_type}")
            except Exception as err:
                _LOGGER.error(f"Chyba při spuštění akce {rule.action_type}: {err}")
                results.append(f"❌ Chyba: {err}")

        return results

    async def _check_conditions(self, conditions: dict[str, Any]) -> bool:
        """Zkontroluj, zda jsou splněny dodatečné podmínky."""
        # TODO: Implementovat kontrolu podmínek (čas, stav entit, apod.)
        return True

    async def _action_unlock_door(self, rule: AccessRule) -> str:
        """Odemkni dvěře."""
        try:
            await self.hass.services.async_call(
                "lock",
                "unlock",
                {"entity_id": rule.target_entity_id},
                blocking=True,
            )
            _LOGGER.info(f"Dveře {rule.target_entity_id} odemčeny pro {rule.person_name}")
            return f"🔓 Dveře odemčeny pro {rule.person_name}"
        except Exception as err:
            _LOGGER.error(f"Nepodařilo se odemknout {rule.target_entity_id}: {err}")
            return f"❌ Nepodařilo se odemknout: {err}"

    async def _action_lock_door(self, rule: AccessRule) -> str:
        """Zamkni dvěře."""
        try:
            await self.hass.services.async_call(
                "lock",
                "lock",
                {"entity_id": rule.target_entity_id},
                blocking=True,
            )
            _LOGGER.info(f"Dveře {rule.target_entity_id} zamčeny")
            return f"🔒 Dveře zamčeny"
        except Exception as err:
            return f"❌ Nepodařilo se zamknout: {err}"

    async def _action_turn_on_light(self, rule: AccessRule) -> str:
        """Rozsvítí světlo."""
        try:
            await self.hass.services.async_call(
                "light",
                "turn_on",
                {"entity_id": rule.target_entity_id},
                blocking=True,
            )
            _LOGGER.info(f"Světlo {rule.target_entity_id} rozsvíceno")
            return f"💡 Světlo rozsvíceno"
        except Exception as err:
            return f"❌ Nepodařilo se rozsvítit: {err}"

    async def _action_turn_off_light(self, rule: AccessRule) -> str:
        """Zhasne světlo."""
        try:
            await self.hass.services.async_call(
                "light",
                "turn_off",
                {"entity_id": rule.target_entity_id},
                blocking=True,
            )
            return f"🌙 Světlo zhasnuty"
        except Exception as err:
            return f"❌ Nepodařilo se zhasnout: {err}"

    async def _action_open_garage(self, rule: AccessRule) -> str:
        """Otevři garážová vrata."""
        try:
            await self.hass.services.async_call(
                "cover",
                "open_cover",
                {"entity_id": rule.target_entity_id},
                blocking=True,
            )
            _LOGGER.info(f"Garáž {rule.target_entity_id} otevřena")
            return f"🚗 Garážová vrata otevřena"
        except Exception as err:
            return f"❌ Nepodařilo se otevřít garáž: {err}"

    async def _action_send_notification(self, rule: AccessRule) -> str:
        """Pošli notifikaci."""
        try:
            message = rule.metadata.get("message", f"{rule.person_name} byl rozpoznán")
            title = rule.metadata.get("title", "🔔 Upozornění")

            await self.hass.services.async_call(
                "notify",
                rule.target_entity_id,
                {"title": title, "message": message},
                blocking=True,
            )
            return f"📬 Notifikace poslána"
        except Exception as err:
            return f"❌ Nepodařilo se poslat notifikaci: {err}"

    async def _action_activate_scene(self, rule: AccessRule) -> str:
        """Spusť scénu (např. 'Příchod domů')."""
        try:
            await self.hass.services.async_call(
                "scene",
                "turn_on",
                {"entity_id": rule.target_entity_id},
                blocking=True,
            )
            _LOGGER.info(f"Scéna {rule.target_entity_id} spuštěna")
            return f"🎬 Scéna spuštěna"
        except Exception as err:
            return f"❌ Nepodařilo se spustit scénu: {err}"

    async def _action_call_service(self, rule: AccessRule) -> str:
        """Zavolej libovolnou Home Assistant službu."""
        try:
            service_data = rule.metadata.get("service_data", {})
            domain, service = rule.target_entity_id.split(".", 1)

            await self.hass.services.async_call(
                domain,
                service,
                service_data,
                blocking=True,
            )
            return f"✅ Služba {domain}.{service} zavolána"
        except Exception as err:
            return f"❌ Chyba při volání služby: {err}"

    async def list_all_rules(self) -> str:
        """Vrať pěkný seznam všech pravidel přístupu."""
        if not self.access_rules:
            return "📭 Žádná pravidla přístupu nejsou nastavena"

        rules_text = "📋 Pravidla přístupu:\n"
        for rule in self.access_rules:
            status = "✅" if rule.enabled else "❌"
            rules_text += f"  {status} {rule.person_name} → {rule.action_type.value} ({rule.target_entity_id})\n"

        return rules_text
