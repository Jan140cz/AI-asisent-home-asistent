"""Tests pro integraci AI Asistent (Ollama)."""
