"""Testy pro module const.py."""

from custom_components.ollama_assistant.const import (
    DOMAIN,
    DEFAULT_MODEL,
    DEFAULT_LANGUAGE,
    LANGUAGE_NAMES,
    LANGUAGE_OPTIONS,
)


def test_domain():
    """Test DOMAIN konstanta."""
    assert DOMAIN == "ollama_assistant"


def test_defaults():
    """Test výchozí hodnoty."""
    assert DEFAULT_MODEL == "llama3.1"
    assert DEFAULT_LANGUAGE == "cs"


def test_language_names():
    """Test seznam dostupných jazyků."""
    assert "cs" in LANGUAGE_NAMES
    assert "en" in LANGUAGE_NAMES
    assert LANGUAGE_NAMES["cs"] == "Čeština"
    assert LANGUAGE_NAMES["en"] == "Angličtina"


def test_language_options():
    """Test formát language options."""
    assert isinstance(LANGUAGE_OPTIONS, list)
    assert len(LANGUAGE_OPTIONS) > 0
    for option in LANGUAGE_OPTIONS:
        assert "value" in option
        assert "label" in option
